package com.salesforce.pages;

import org.openqa.selenium.WebElement;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	public LoginPage enterUserName(String uName) {
		WebElement eleUname = locateElement("username");
		type(eleUname, uName);
		reportStep("uName is enterd sucessfully", uName, true);
		return this;
		
	}
	
	public LoginPage enterPassword(String pWord) {
		
		WebElement elePword = locateElement(Locators.XPATH, "//input[@id='password']");
		type(elePword, pWord);
		return this;

	}
	
	public Homepage clickLogin() {
		click(locateElement("Login"));
		return new Homepage();
	}
	
}
