package com.salesforce.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.ProjectSpecificMethods;
import com.salesforce.pages.LoginPage;

public class verifyLogin extends ProjectSpecificMethods {
	
	@BeforeTest
	public void setValues() {
		excelFileName="Login";
		testcaseName="Login";
		testDescription="Login with positivecfedentials";
		authors="saranya";
		category="smoke";
		
		
	}
	
	
	
	
	@Test(dataProvider = "fetchData")
	public void runLogin(String uName,String pWord) {
		new LoginPage().enterUserName(uName).enterPassword(pWord).clickLogin();

	}
	
}
